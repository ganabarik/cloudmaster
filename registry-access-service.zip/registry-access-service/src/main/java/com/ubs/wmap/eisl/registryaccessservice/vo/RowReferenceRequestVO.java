package com.ubs.wmap.eisl.registryaccessservice.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class RowReferenceRequestVO implements Serializable {

	private static final long serialVersionUID = 388516328059686097L;
	private String name;
	private String range;
}