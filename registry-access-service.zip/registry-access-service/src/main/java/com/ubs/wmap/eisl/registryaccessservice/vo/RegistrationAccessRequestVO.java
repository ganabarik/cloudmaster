package com.ubs.wmap.eisl.registryaccessservice.vo;

import java.io.Serializable;
import java.util.Set;

import lombok.Data;
import lombok.EqualsAndHashCode;
@Data
public class RegistrationAccessRequestVO implements Serializable{

	private static final long serialVersionUID = -4468317526043638777L;
	private String userId;
	private String company;
	private String role;
	private String eislToken;
	/*@EqualsAndHashCode.Exclude
	private RoleRequestVO roles;*/
	@EqualsAndHashCode.Exclude
	private Set<ColumnReferenceRequestVO> columnReferences;
	@EqualsAndHashCode.Exclude
	private Set<RowReferenceRequestVO> rowReferences;
}
