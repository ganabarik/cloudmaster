package com.ubs.wmap.eisl.registryaccessservice.vo;

import java.io.Serializable;
import java.util.Set;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
public class RegistrationRequestVO implements Serializable{

	private static final long serialVersionUID = 6349874774163306834L;
	private String userName;
	private String company;
	private String role;
	/*@EqualsAndHashCode.Exclude
	private RoleRequestVO roles;*/
	@EqualsAndHashCode.Exclude
	private Set<ColumnReferenceRequestVO> columnReferences;
	@EqualsAndHashCode.Exclude
	private Set<RowReferenceRequestVO> rowReferences;
}