package com.ubs.wmap.eisl.registryaccessservice.exception;

public class RegistryReferenceException extends Exception {
	private static final long serialVersionUID = 5172706732973364925L;

	public RegistryReferenceException(String message) {
		super(message);
	}
	public RegistryReferenceException(Throwable cause) {
		super(cause);
	}
	public RegistryReferenceException(String message, Throwable cause) {
		super(message, cause);
	}
	@Override
	public String getMessage() {
		return super.getMessage();
	}
}
