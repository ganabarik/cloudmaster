package com.ubs.wmap.eisl.registryaccessservice;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.registryaccessservice.context.EislClaimsContext;
import com.ubs.wmap.eisl.registryaccessservice.context.EislClaimsContextHolder;
import io.jsonwebtoken.Claims;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.util.NestedServletException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ubs.wmap.eisl.registryaccessservice.controller.RegistryAccessController;
import com.ubs.wmap.eisl.registryaccessservice.service.RegistryReferenceService;
import com.ubs.wmap.eisl.registryaccessservice.util.EislClaimsContextUtil;
import com.ubs.wmap.eisl.registryaccessservice.vo.ColumnReferenceRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.ColumnReferenceResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistryAccessRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RoleRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RoleResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RowReferenceRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RowReferenceResponseVO;

@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ComponentScan(basePackages = {"com.ubs.wmap.eisl.registryaccessservice"})
public class RegistryAccessControllerTest {
    private MockMvc mockMvc;

    @Mock
    private RegistryReferenceService registryReferenceService;
    @Mock
    private EislClaimsContextUtil eislClaimsContextUtil;
    @InjectMocks
    private RegistryAccessController registryAccessController;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    private RegistryAccessController controller;

    @Mock
    private TokenService tokenService;

    @Before
    public void setup() {
    	mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
        mockMvc= MockMvcBuilders.standaloneSetup(registryAccessController).build();
    }
    //@Test
    public void testGetRegistryDetails() throws Exception {

        RegistryAccessRequestVO registryRequestVO = new RegistryAccessRequestVO();
        registryRequestVO.setServiceId("testService");
        registryRequestVO.setUserId("user123");
        registryRequestVO.setRole("publish");
        Mockito.when(eislClaimsContextUtil.getContextParam("serviceId")).thenReturn("testService");
        Map<String, Object> claims = createEislContext();
        Mockito.when(tokenService.init("eisl-Token")).thenReturn(claims);
        Mockito.when(registryReferenceService.getRegistryReference(registryRequestVO)).thenReturn(getRegistrationResponse(false));
        mockMvc.perform(get("/registrations/{role}","publish").param("token", "eisl-Token")).andDo(print()).andExpect(status().isOk())
                .andExpect(content().contentType("application/json;charset=UTF-8"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.columnReferences").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.rowReferences").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.serviceId").value("testService"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.userName").value("Test-User1"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.userId").value("test123"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.role").value("publish"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.eislToken").value("token-sample"));
    }

    //@Test
    public void testSaveRegistryDetails() throws Exception {
        createEislContext();
        Mockito.when(registryReferenceService.persistRegistry(getRegistrationRequestData())).thenReturn(getRegistrationResponse(true));
        Map<String, Object> claims = createEislContext();
        Mockito.when(tokenService.init("eisl-Token")).thenReturn(claims);
        mockMvc.perform(post("/registrations").contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(getRegistrationRequestData())).param("token", "eisl-Token")).andDo(print()).andExpect(status().isOk())
                .andExpect(content().contentType("application/json;charset=UTF-8"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.columnReferences").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.rowReferences").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.registrationId").value(1))
                .andExpect(MockMvcResultMatchers.jsonPath("$.serviceId").value("testService"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.userName").value("Test-User1"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.userId").value("test123"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.role").value("publish"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.eislToken").value("token-sample"));
    }



    //@Test(expected = Exception.class)
    public void whenGetDataReferenceExceptionCaught() throws Exception {
        controller.getRegistryDetails("vsfsd-hbjh-hbhj","dds");
    }

    private RegistrationRequestVO getRegistrationRequestData() {
        RegistrationRequestVO registrationRequestVO = new RegistrationRequestVO();
        registrationRequestVO.setCompany("testcomp");
       /* registrationRequestVO.setDataEntitlement("dataent");
        registrationRequestVO.setEislToken("qbcde");
        registrationRequestVO.setServiceId("TestService1");
        registrationRequestVO.setUserId("testuser");
        registrationRequestVO.setUserName("user");*/
        RoleRequestVO roleRequestVO = new RoleRequestVO();
        roleRequestVO.setName("TestConsume");
       /* registrationRequestVO.setRole(roleRequestVO);*/
        Set<ColumnReferenceRequestVO> columnReferences = new HashSet<>();
        Set<RowReferenceRequestVO> rowReferences = new HashSet<>();
        ColumnReferenceRequestVO columnReferenceRequestVO = new ColumnReferenceRequestVO();
        columnReferenceRequestVO.setName("name");
        columnReferenceRequestVO.setType("type");
        columnReferences.add(columnReferenceRequestVO);
        RowReferenceRequestVO rowReferenceRequestVO = new RowReferenceRequestVO();
        rowReferenceRequestVO.setName("reowName");
        rowReferenceRequestVO.setRange("rangeType");
        rowReferences.add(rowReferenceRequestVO);
        registrationRequestVO.setColumnReferences(columnReferences);
        registrationRequestVO.setRowReferences(rowReferences);

        return registrationRequestVO;
    }
    private RegistrationResponseVO getRegistrationResponse(boolean isIdRequired) {
        RegistrationResponseVO registrationResponseVO = new RegistrationResponseVO();
        if(isIdRequired) {
            registrationResponseVO.setRegistrationId(1L);
        }
        registrationResponseVO.setServiceId("testService");
        registrationResponseVO.setCompany("ubs");
        registrationResponseVO.setEislToken("token-sample");
        registrationResponseVO.setRegistrationId(1L);
        registrationResponseVO.setUserName("Test-User1");
        registrationResponseVO.setUserId("test123");
        registrationResponseVO.setRole("publish");
        RoleResponseVO roleresp = new RoleResponseVO();
        if(isIdRequired) {
            roleresp.setRoleId(1L);
        }
        roleresp.setName("consume");
      /*  registrationResponseVO.setRole(roleresp);*/

        Set<ColumnReferenceResponseVO> columnReferences = new HashSet<>();

        ColumnReferenceResponseVO col = new ColumnReferenceResponseVO();
        if(isIdRequired) {
            col.setColumnReferenceId(1);
        }
        col.setJsonModel("jsonmodel");
        col.setName("name");
        col.setProjectionId("1");
        columnReferences.add(col);

        Set<RowReferenceResponseVO> rowReferences = new HashSet<>();
        RowReferenceResponseVO row = new RowReferenceResponseVO();
        row.setName("rowname");
        row.setRange("range");
        if(isIdRequired) {
            row.setRowReferenceId(1);
        }
        rowReferences.add(row);
        registrationResponseVO.setColumnReferences(columnReferences);
        registrationResponseVO.setRowReferences(rowReferences);
        return registrationResponseVO;
    }
    private String asJsonString(RegistrationRequestVO request) {
        String asJson = null;
        try {
            asJson = new ObjectMapper().writeValueAsString(request);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return asJson;
    }

    private Map<String, Object> createEislContext() {
        Map<String, Object> claims = new HashMap<>();
        claims.put("userNameClaim", "Test-User1");
        claims.put("serviceIdClaim", "testService");
        claims.put("claims","claims");
        claims.put("role", "roleInput");
        return claims;
    }
}
